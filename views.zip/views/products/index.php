		<?php
		foreach ($products as $product)
		{
		?>
			<div class="">
				<button type="button" class="btn btn-alert"><?php echo $product->name?></button>
			</div>
		<?php
		}
		?>
